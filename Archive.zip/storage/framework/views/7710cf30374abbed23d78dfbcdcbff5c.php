<?php echo $__env->make('include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
   
    <?php echo $__env->make('include/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(!request()->is('contactus')): ?>
    <?php echo $__env->make('searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('namebox'); ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /Users/kalaiarasu/Arasu/mac_localhost/LaravelAp/babyname/resources/views/index.blade.php ENDPATH**/ ?>