<?php $__env->startSection('content'); ?>
<section id="category">
    <div class="container ">
        <div class="mt-4 d-md-flex justify-content-between align-items-center">
            <div>
                <h3><?php echo e($start_letter); ?> Starting Letter <?php echo e($gender); ?> Baby Name List</h3>
            </div>
        </div>
        <div class="row g-md-3 mt-2">
            <?php $__currentLoopData = $nameList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            
            $namesss = mb_substr($name->tamil_name,0,2);
            ?>
            <?php if($nameList == mb_substr($name,0,2)): ?>
            <div>
                <h3><?php echo e($start_letter); ?> Starting Letter <?php echo e($namesss); ?> Baby Name List</h3>
            </div>
            <?php endif; ?>
            <div class="col-md-3 pt-1">
                <div class="<?php echo e(Arr::random(['gray','primary','secondary','tertiary'])); ?> rounded-3 p-2">
                    <div class="d-flex align-items-center">
                        <?php if($name->gender == 'M'): ?>
                       <img src="<?php echo e(asset('images/icons8-boy-48.png')); ?>">
                       <?php else: ?>
                       <img src="<?php echo e(asset('images/icons8-girl-48.png')); ?>">
                       <?php endif; ?>
                        <div class="ps-2">
                            <?php if($nametype == 'ta'): ?>
                            <p class="category-paragraph fw-bold text-uppercase mb-1"><?php echo e($name->tamil_name); ?></p>
                            <p class="category-paragraph m-0"><?php echo e($name->name); ?></p>
                            <?php else: ?>
                            <p class="category-paragraph fw-bold text-uppercase mb-1"><?php echo e($name->name); ?></p>
                            <p class="category-paragraph m-0"><?php echo e($name->tamil_name); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name_start'); ?>
<div class="row justify-content-center">
    <div class="col-auto">
        <div class="d-flex justify-content-between py-1" style="overflow:auto">
            <?php $__currentLoopData = $en_letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/babyname/')); ?>/<?php echo e($gender); ?>/<?php echo e($letters->nameletter); ?>" class="btn btn-outline-primary m-1 <?php echo e(($letters->nameletter==$start_letter) ? 'active activename' : ''); ?> "><?php echo e($letters->nameletter); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-between py-1" style="overflow:auto">
            <?php $__currentLoopData = $ta_letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/babyname/')); ?>/<?php echo e($gender); ?>/<?php echo e($letters->nameletter); ?>" class="btn btn-outline-primary m-1 <?php echo e(($letters->nameletter==$start_letter) ? 'active activename' : ''); ?> "><?php echo e($letters->nameletter); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', ['title'=> $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/nameList.blade.php ENDPATH**/ ?>