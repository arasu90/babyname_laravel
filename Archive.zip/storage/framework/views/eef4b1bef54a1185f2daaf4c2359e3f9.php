<?php $__env->startSection('content'); ?>
<section id="category">
    <div class="container ">
        <div class="mt-4 d-md-flex justify-content-between align-items-center">
            <div>
                <h3><?php echo e($start_letter); ?> Starting Letter <?php echo e($gender); ?> Baby Name List</h3>
            </div>
        </div>
        <div class="row g-md-3 mt-2">
            <?php $__currentLoopData = $nameList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 pt-1">
                <div class="<?php echo e(Arr::random(['gray','primary','secondary','tertiary'])); ?> rounded-3 p-2">
                    <div class="d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60px" height="60px">
                            <use href="#pencil-box" class="svg-primary" />
                        </svg>
                        <div class="ps-2">
                            <p class="category-paragraph fw-bold text-uppercase mb-1"><?php echo e($name->name); ?></p>
                            <p class="category-paragraph m-0"><?php echo e($name->tamil_name); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name_start'); ?>
<div class="row justify-content-center">
    <div class="col-auto">
        <div class="d-flex justify-content-between py-5" style="overflow:auto">
            <?php for($x = ord('a'); $x <= ord('z'); $x++): ?> 
                <a href="<?php echo e(url('/babyname/')); ?>/<?php echo e($gender); ?>/<?php echo e(chr($x)); ?>" class="btn btn-outline-primary m-1 <?php echo e((chr($x)==$start_letter) ? 'active activename' : ''); ?> "><?php echo e(chr($x)); ?></a>
            <?php endfor; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', ['title'=> $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kalaiarasu/Arasu/mac_localhost/babyname/resources/views/nameList.blade.php ENDPATH**/ ?>