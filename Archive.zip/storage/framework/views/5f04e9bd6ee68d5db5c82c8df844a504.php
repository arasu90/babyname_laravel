<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Boy Baby Name & Girl Baby Name</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="p-5">
                        <form class="user" method="post" action="/updatename/<?php echo e($editname->id); ?>">

                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="form-label" class="label-control">Name</label>
                                <input type="text" class="form-control form-control-user"
                                    name="inputName" aria-describedby="emailHelp"
                                    placeholder="Enter Name..." value="<?php echo e($editname->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Gender</label>
                                <select name="gender" id="gender" class="form-control">
                                    <option value="">Select</option>
                                    <option value="M" <?php if($editname->gender == 'M'): ?> selected  <?php endif; ?> >Male</option>
                                    <option value="F" <?php if($editname->gender == 'F'): ?> selected  <?php endif; ?> >Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="form-label" class="label-control">Laungage Name</label>
                                <input type="text" class="form-control form-control-user"
                                    id="exampleInputEmail" aria-describedby="emailHelp"
                                    placeholder="Enter Laungage Name">
                            </div>
                            <div class="form-group">
                               <button type="submit" class="form-control btn btn-success">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kalaiarasu/Arasu/mac_localhost/LaravelAp/babyname/resources/views/admin/editname.blade.php ENDPATH**/ ?>