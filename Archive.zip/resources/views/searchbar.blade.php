<section id="hero" style="background-image:url('{{asset('/images/billboard-bg.png')}}'); background-repeat: no-repeat; height:250px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 pe-5 mt-5 mt-md-0">
                <h2 class="display-1 text-uppercase">Find Your Baby Name</h2>
                @yield('name_start')
            </div>
        </div>

    </div>

</section>